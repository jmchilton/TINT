package edu.umn.msi.tropix.proteomics.cagrid.sequest.service;

import java.rmi.RemoteException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import edu.umn.msi.cagrid.introduce.interfaces.spring.client.Services;
import edu.umn.msi.tropix.proteomics.cagrid.sequest.service.SequestConfiguration;

public class SequestApplicationContext {
  static {
    Services.registerService("edu.umn.msi.tropix.proteomics.cagrid.sequest.SequestImpl");
  }

  private static FileSystemXmlApplicationContext applicationContext;

  public static void init(SequestConfiguration serviceConfiguration) throws RemoteException
  {
    if(applicationContext == null)
    {
      try 
      {
        String applicationContextPath = "file:" + serviceConfiguration.getApplicationContext();
        applicationContext = new FileSystemXmlApplicationContext(applicationContextPath);
        applicationContext.registerShutdownHook();
        Services.setApplicationContext(applicationContext);
      }
      catch(Exception e) 
      {
        e.printStackTrace();
        throw new RemoteException("Failed to initialize spring.",e);
      }
    }
  }

  public static ApplicationContext get() 
  {
    return applicationContext;
  }
}


