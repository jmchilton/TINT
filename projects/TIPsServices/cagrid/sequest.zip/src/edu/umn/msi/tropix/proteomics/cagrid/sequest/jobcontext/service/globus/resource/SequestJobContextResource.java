package edu.umn.msi.tropix.proteomics.cagrid.sequest.jobcontext.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this SequestJobContextResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class SequestJobContextResource extends SequestJobContextResourceBase {

}
