package edu.umn.msi.tropix.proteomics.cagrid.sequest.common;

import javax.xml.namespace.QName;


public interface SequestConstants {
	public static final String SERVICE_NS = "http://msi.umn.edu/tropix/proteomics/cagrid/Sequest";
	public static final QName RESOURCE_KEY = new QName(SERVICE_NS, "SequestKey");
	public static final QName RESOURCE_PROPERTY_SET = new QName(SERVICE_NS, "SequestResourceProperties");

	//Service level metadata (exposed as resouce properties)
	public static final QName SERVICEMETADATA = new QName("gme://caGrid.caBIG/1.0/gov.nih.nci.cagrid.metadata", "ServiceMetadata");
	public static final QName QUEUESTATUS = new QName("http://msi.umn.edu/tropix/common/jobqueue/queueStatus", "QueueStatus");
	public static final QName IDENTIFICATIONMETADATA = new QName("http://msi.umn.edu/tropix/proteomics/cagrid/metadata", "IdentificationMetadata");
	
}
