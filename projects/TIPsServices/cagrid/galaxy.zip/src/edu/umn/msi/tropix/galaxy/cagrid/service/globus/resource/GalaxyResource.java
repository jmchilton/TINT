package edu.umn.msi.tropix.galaxy.cagrid.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this GalaxyResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class GalaxyResource extends GalaxyResourceBase {

}
