package edu.umn.msi.tropix.proteomics.cagrid.omssa.jobcontext.client;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

public class OmssaJobContextInterfacesClient implements edu.umn.msi.tropix.proteomics.service.OmssaJobQueueContext  {
  private OmssaJobContextClient caGridClient;

  public OmssaJobContextInterfacesClient(String url) throws MalformedURIException, RemoteException {
    initialize(new OmssaJobContextClient(url));
  }
  
  public OmssaJobContextInterfacesClient(String url, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new OmssaJobContextClient(url, proxy));
  }

  public OmssaJobContextInterfacesClient(EndpointReferenceType epr) throws MalformedURIException, RemoteException {
    initialize(new OmssaJobContextClient(epr));
  }

  public OmssaJobContextInterfacesClient(EndpointReferenceType epr, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new OmssaJobContextClient(epr, proxy));
  }
  
  public OmssaJobContextInterfacesClient(OmssaJobContextClient caGridClient) {
    initialize(caGridClient);
  }
        
  private void initialize(OmssaJobContextClient caGridClient) {
    this.caGridClient = caGridClient;
  }		        

  public OmssaJobContextClient getCaGridClient() {
  	return caGridClient;
  }
       
  public void submitJob(edu.umn.msi.tropix.transfer.types.TransferResource arg1,edu.umn.msi.tropix.transfer.types.TransferResource arg2,edu.umn.msi.tropix.credential.types.CredentialResource arg3,gov.nih.nlm.ncbi.omssa.MSSearchSettings arg4) 
  {
    try 
    {
      caGridClient.submitJob(arg1,arg2,arg3,arg4);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public int getNumResults() 
  {
    try 
    {
      return caGridClient.getNumResults();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public void getResults(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2) 
  {
    try 
    {
      caGridClient.getResults(arg1,arg2);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public void cancel() 
  {
    try 
    {
      caGridClient.cancel();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public edu.umn.msi.tropix.common.jobqueue.status.Status getStatus() 
  {
    try 
    {
      return caGridClient.getStatus();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public edu.umn.msi.tropix.common.jobqueue.ticket.Ticket getTicket() 
  {
    try 
    {
      return caGridClient.getTicket();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
  
  /**
   * The caGrid client methods throw RemoteExceptions. But most
   * methods of most interfaces do not declare RemoteExceptions.
   * For that reason when building a client class that implements
   * methods that do not allow RemoteExceptions, they are caught
   * and wrapped in this RuntimeException which does not need to 
   * be declared, allowing the client class to implement the 
   * specified interface.
   *
   */
  public class RemoteRuntimeException extends RuntimeException {
   
    public RemoteRuntimeException(RemoteException exception) {
      super(exception);
    }
    
    /**
     * @return The wrapped RemoteException.
     */
    public RemoteException getRemoteException() {
      Throwable cause = getCause();
      if(cause instanceof RemoteException) {
        return (RemoteException) cause;
      } else {
        throw new IllegalStateException("getCause() did not return a RemoteException");
      }
    }
  }
}
