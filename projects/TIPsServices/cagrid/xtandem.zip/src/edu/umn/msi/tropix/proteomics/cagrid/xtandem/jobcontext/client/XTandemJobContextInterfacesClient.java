package edu.umn.msi.tropix.proteomics.cagrid.xtandem.jobcontext.client;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

public class XTandemJobContextInterfacesClient implements edu.umn.msi.tropix.proteomics.service.XTandemJobQueueContext  {
  private XTandemJobContextClient caGridClient;

  public XTandemJobContextInterfacesClient(String url) throws MalformedURIException, RemoteException {
    initialize(new XTandemJobContextClient(url));
  }
  
  public XTandemJobContextInterfacesClient(String url, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new XTandemJobContextClient(url, proxy));
  }

  public XTandemJobContextInterfacesClient(EndpointReferenceType epr) throws MalformedURIException, RemoteException {
    initialize(new XTandemJobContextClient(epr));
  }

  public XTandemJobContextInterfacesClient(EndpointReferenceType epr, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new XTandemJobContextClient(epr, proxy));
  }
  
  public XTandemJobContextInterfacesClient(XTandemJobContextClient caGridClient) {
    initialize(caGridClient);
  }
        
  private void initialize(XTandemJobContextClient caGridClient) {
    this.caGridClient = caGridClient;
  }		        

  public XTandemJobContextClient getCaGridClient() {
  	return caGridClient;
  }
       
  public void submitJob(edu.umn.msi.tropix.transfer.types.TransferResource arg1,edu.umn.msi.tropix.transfer.types.TransferResource arg2,edu.umn.msi.tropix.credential.types.CredentialResource arg3,edu.umn.msi.tropix.models.xtandem.cagrid.XTandemParameters arg4) 
  {
    try 
    {
      caGridClient.submitJob(arg1,arg2,arg3,arg4);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public int getNumResults() 
  {
    try 
    {
      return caGridClient.getNumResults();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public void getResults(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2) 
  {
    try 
    {
      caGridClient.getResults(arg1,arg2);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public void cancel() 
  {
    try 
    {
      caGridClient.cancel();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public edu.umn.msi.tropix.common.jobqueue.status.Status getStatus() 
  {
    try 
    {
      return caGridClient.getStatus();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public edu.umn.msi.tropix.common.jobqueue.ticket.Ticket getTicket() 
  {
    try 
    {
      return caGridClient.getTicket();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
  
  /**
   * The caGrid client methods throw RemoteExceptions. But most
   * methods of most interfaces do not declare RemoteExceptions.
   * For that reason when building a client class that implements
   * methods that do not allow RemoteExceptions, they are caught
   * and wrapped in this RuntimeException which does not need to 
   * be declared, allowing the client class to implement the 
   * specified interface.
   *
   */
  public class RemoteRuntimeException extends RuntimeException {
   
    public RemoteRuntimeException(RemoteException exception) {
      super(exception);
    }
    
    /**
     * @return The wrapped RemoteException.
     */
    public RemoteException getRemoteException() {
      Throwable cause = getCause();
      if(cause instanceof RemoteException) {
        return (RemoteException) cause;
      } else {
        throw new IllegalStateException("getCause() did not return a RemoteException");
      }
    }
  }
}
