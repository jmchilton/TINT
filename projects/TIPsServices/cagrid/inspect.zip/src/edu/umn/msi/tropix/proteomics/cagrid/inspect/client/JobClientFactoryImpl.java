package edu.umn.msi.tropix.proteomics.cagrid.inspect.client;

import java.rmi.RemoteException;
import javax.annotation.Nullable;

import edu.umn.msi.tropix.common.jobqueue.client.JobClientFactory;
import edu.umn.msi.tropix.common.jobqueue.client.JobClientFactoryComponent;
import edu.umn.msi.tropix.common.jobqueue.ticket.Ticket;
import edu.umn.msi.tropix.grid.credentials.Credential;

import org.springframework.stereotype.Component;

import org.apache.axis.types.URI.MalformedURIException;

import org.globus.gsi.GlobusCredential;

import edu.umn.msi.tropix.proteomics.cagrid.inspect.client.*;
import edu.umn.msi.tropix.proteomics.cagrid.inspect.jobcontext.client.*;

@Component("edu.umn.msi.tropix.proteomics.cagrid.inspect.JobClientFactory") @JobClientFactoryComponent(serviceName = "Inspect", servicePackage = "edu.umn.msi.tropix.proteomics.cagrid.inspect")
public class JobClientFactoryImpl implements JobClientFactory {

  public <T> T createJobContext(@Nullable Credential credential, String serviceUrl, Class<T> interfaceClass) {
    try {
      InspectClient client = new InspectClient(serviceUrl, getGlobusCredential(credential));
      InspectJobContextClient jobClient = client.createJob();
      return (T) new InspectJobContextInterfacesClient(jobClient);
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }
  
  public <T> T getJobClient(@Nullable Credential credential, String serviceUrl, Ticket ticket, Class<T> interfaceClass) {
    try {
      InspectClient client = new InspectClient(serviceUrl, getGlobusCredential(credential));
      InspectJobContextClient jobClient = client.getJob(ticket);
      return (T) new InspectJobContextInterfacesClient(jobClient);        
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }
  
  public <T> T getServiceClient(@Nullable Credential credential, String serviceUrl, Class<T> interfaceClass) {
    try {
      InspectInterfacesClient iClient = new InspectInterfacesClient(serviceUrl, getGlobusCredential(credential));
      return (T) iClient;  
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }

  @Nullable
  private GlobusCredential getGlobusCredential(@Nullable Credential credential) {
    return credential == null ? null : credential.getGlobusCredential();
  }
  

}
