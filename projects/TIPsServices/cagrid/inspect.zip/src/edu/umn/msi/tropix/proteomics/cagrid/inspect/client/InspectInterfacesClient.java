package edu.umn.msi.tropix.proteomics.cagrid.inspect.client;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

public class InspectInterfacesClient implements edu.umn.msi.tropix.common.jobqueue.service.StatusService  {
  private InspectClient caGridClient;

  public InspectInterfacesClient(String url) throws MalformedURIException, RemoteException {
    initialize(new InspectClient(url));
  }
  
  public InspectInterfacesClient(String url, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new InspectClient(url, proxy));
  }

  public InspectInterfacesClient(EndpointReferenceType epr) throws MalformedURIException, RemoteException {
    initialize(new InspectClient(epr));
  }

  public InspectInterfacesClient(EndpointReferenceType epr, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new InspectClient(epr, proxy));
  }
  
  public InspectInterfacesClient(InspectClient caGridClient) {
    initialize(caGridClient);
  }
        
  private void initialize(InspectClient caGridClient) {
    this.caGridClient = caGridClient;
  }		        

  public InspectClient getCaGridClient() {
  	return caGridClient;
  }
       
  public edu.umn.msi.tropix.common.jobqueue.status.Status[] getStatuses(edu.umn.msi.tropix.common.jobqueue.ticket.Ticket[] arg1) 
  {
    try 
    {
      return caGridClient.getStatuses(arg1);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
  
  /**
   * The caGrid client methods throw RemoteExceptions. But most
   * methods of most interfaces do not declare RemoteExceptions.
   * For that reason when building a client class that implements
   * methods that do not allow RemoteExceptions, they are caught
   * and wrapped in this RuntimeException which does not need to 
   * be declared, allowing the client class to implement the 
   * specified interface.
   *
   */
  public class RemoteRuntimeException extends RuntimeException {
   
    public RemoteRuntimeException(RemoteException exception) {
      super(exception);
    }
    
    /**
     * @return The wrapped RemoteException.
     */
    public RemoteException getRemoteException() {
      Throwable cause = getCause();
      if(cause instanceof RemoteException) {
        return (RemoteException) cause;
      } else {
        throw new IllegalStateException("getCause() did not return a RemoteException");
      }
    }
  }
}
