package edu.umn.msi.tropix.proteomics.cagrid.tagrecon.client;

import java.rmi.RemoteException;
import javax.annotation.Nullable;

import edu.umn.msi.tropix.common.jobqueue.client.JobClientFactory;
import edu.umn.msi.tropix.common.jobqueue.client.JobClientFactoryComponent;
import edu.umn.msi.tropix.common.jobqueue.ticket.Ticket;
import edu.umn.msi.tropix.grid.credentials.Credential;

import org.springframework.stereotype.Component;

import org.apache.axis.types.URI.MalformedURIException;

import org.globus.gsi.GlobusCredential;

import edu.umn.msi.tropix.proteomics.cagrid.tagrecon.client.*;
import edu.umn.msi.tropix.proteomics.cagrid.tagrecon.jobcontext.client.*;

@Component("edu.umn.msi.tropix.proteomics.cagrid.tagrecon.JobClientFactory") @JobClientFactoryComponent(serviceName = "TagRecon", servicePackage = "edu.umn.msi.tropix.proteomics.cagrid.tagrecon")
public class JobClientFactoryImpl implements JobClientFactory {

  public <T> T createJobContext(@Nullable Credential credential, String serviceUrl, Class<T> interfaceClass) {
    try {
      TagReconClient client = new TagReconClient(serviceUrl, getGlobusCredential(credential));
      TagReconJobContextClient jobClient = client.createJob();
      return (T) new TagReconJobContextInterfacesClient(jobClient);
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }
  
  public <T> T getJobClient(@Nullable Credential credential, String serviceUrl, Ticket ticket, Class<T> interfaceClass) {
    try {
      TagReconClient client = new TagReconClient(serviceUrl, getGlobusCredential(credential));
      TagReconJobContextClient jobClient = client.getJob(ticket);
      return (T) new TagReconJobContextInterfacesClient(jobClient);        
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }
  
  public <T> T getServiceClient(@Nullable Credential credential, String serviceUrl, Class<T> interfaceClass) {
    try {
      TagReconInterfacesClient iClient = new TagReconInterfacesClient(serviceUrl, getGlobusCredential(credential));
      return (T) iClient;  
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }

  @Nullable
  private GlobusCredential getGlobusCredential(@Nullable Credential credential) {
    return credential == null ? null : credential.getGlobusCredential();
  }
  

}
