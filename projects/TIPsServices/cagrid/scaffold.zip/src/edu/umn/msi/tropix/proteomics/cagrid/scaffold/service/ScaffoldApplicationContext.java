package edu.umn.msi.tropix.proteomics.cagrid.scaffold.service;

import java.rmi.RemoteException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import edu.umn.msi.cagrid.introduce.interfaces.spring.client.Services;
import edu.umn.msi.tropix.proteomics.cagrid.scaffold.service.ScaffoldConfiguration;

public class ScaffoldApplicationContext {
  static {
    Services.registerService("edu.umn.msi.tropix.proteomics.cagrid.scaffold.ScaffoldImpl");
  }

  private static FileSystemXmlApplicationContext applicationContext;

  public static void init(ScaffoldConfiguration serviceConfiguration) throws RemoteException
  {
    if(applicationContext == null)
    {
      try 
      {
        String applicationContextPath = "file:" + serviceConfiguration.getApplicationContext();
        applicationContext = new FileSystemXmlApplicationContext(applicationContextPath);
        applicationContext.registerShutdownHook();
        Services.setApplicationContext(applicationContext);
      }
      catch(Exception e) 
      {
        e.printStackTrace();
        throw new RemoteException("Failed to initialize spring.",e);
      }
    }
  }

  public static ApplicationContext get() 
  {
    return applicationContext;
  }
}


