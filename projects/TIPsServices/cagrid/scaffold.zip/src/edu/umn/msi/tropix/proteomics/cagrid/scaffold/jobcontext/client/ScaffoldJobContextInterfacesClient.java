package edu.umn.msi.tropix.proteomics.cagrid.scaffold.jobcontext.client;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

public class ScaffoldJobContextInterfacesClient implements edu.umn.msi.tropix.proteomics.service.ScaffoldJobQueueContext  {
  private ScaffoldJobContextClient caGridClient;

  public ScaffoldJobContextInterfacesClient(String url) throws MalformedURIException, RemoteException {
    initialize(new ScaffoldJobContextClient(url));
  }
  
  public ScaffoldJobContextInterfacesClient(String url, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new ScaffoldJobContextClient(url, proxy));
  }

  public ScaffoldJobContextInterfacesClient(EndpointReferenceType epr) throws MalformedURIException, RemoteException {
    initialize(new ScaffoldJobContextClient(epr));
  }

  public ScaffoldJobContextInterfacesClient(EndpointReferenceType epr, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new ScaffoldJobContextClient(epr, proxy));
  }
  
  public ScaffoldJobContextInterfacesClient(ScaffoldJobContextClient caGridClient) {
    initialize(caGridClient);
  }
        
  private void initialize(ScaffoldJobContextClient caGridClient) {
    this.caGridClient = caGridClient;
  }		        

  public ScaffoldJobContextClient getCaGridClient() {
  	return caGridClient;
  }
       
  public void submitJob(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2,edu.umn.msi.tropix.proteomics.scaffold.input.cagrid.Scaffold arg3) 
  {
    try 
    {
      caGridClient.submitJob(arg1,arg2,arg3);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public int getNumResults() 
  {
    try 
    {
      return caGridClient.getNumResults();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public void getResults(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2) 
  {
    try 
    {
      caGridClient.getResults(arg1,arg2);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public void cancel() 
  {
    try 
    {
      caGridClient.cancel();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public edu.umn.msi.tropix.common.jobqueue.status.Status getStatus() 
  {
    try 
    {
      return caGridClient.getStatus();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
       
  public edu.umn.msi.tropix.common.jobqueue.ticket.Ticket getTicket() 
  {
    try 
    {
      return caGridClient.getTicket();
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
  
  /**
   * The caGrid client methods throw RemoteExceptions. But most
   * methods of most interfaces do not declare RemoteExceptions.
   * For that reason when building a client class that implements
   * methods that do not allow RemoteExceptions, they are caught
   * and wrapped in this RuntimeException which does not need to 
   * be declared, allowing the client class to implement the 
   * specified interface.
   *
   */
  public class RemoteRuntimeException extends RuntimeException {
   
    public RemoteRuntimeException(RemoteException exception) {
      super(exception);
    }
    
    /**
     * @return The wrapped RemoteException.
     */
    public RemoteException getRemoteException() {
      Throwable cause = getCause();
      if(cause instanceof RemoteException) {
        return (RemoteException) cause;
      } else {
        throw new IllegalStateException("getCause() did not return a RemoteException");
      }
    }
  }
}
