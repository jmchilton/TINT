package edu.umn.msi.tropix.proteomics.cagrid.scaffold.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this ScaffoldResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class ScaffoldResource extends ScaffoldResourceBase {

}
