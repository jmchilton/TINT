package edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.jobcontext.service;

import edu.umn.msi.cagrid.introduce.interfaces.client.service.ImplementsForService;
import edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.service.ITraqQuantitationConfiguration;
import edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.service.ITraqQuantitationApplicationContext;
import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class ITraqQuantitationJobContextImpl extends ITraqQuantitationJobContextImplBase {
  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  java.lang.Object __springBean__1;

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  @ImplementsForService(interfaces = {"edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext"})
  private java.lang.Object get__springBean__1() {
    if(__springBean__1 == null) 
      __springBean__1 =  (java.lang.Object) ITraqQuantitationApplicationContext.get().getBean("iTraqQuantitationService");
    return __springBean__1; 
  }

	public ITraqQuantitationJobContextImpl() throws RemoteException {
		super();
	}
	
  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void submitJob(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.transfer.types.TransferResource arg2,edu.umn.msi.tropix.proteomics.itraqquantitation.options.QuantificationType arg3,edu.umn.msi.tropix.proteomics.itraqquantitation.weight.QuantificationWeights arg4,edu.umn.msi.tropix.credential.types.CredentialResource arg5) throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).submitJob(arg1,arg2,arg3,arg4,arg5);
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void submitTrainingJob(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.transfer.types.TransferResource arg2,edu.umn.msi.tropix.proteomics.itraqquantitation.options.QuantificationType arg3,edu.umn.msi.tropix.proteomics.itraqquantitation.training.QuantificationTrainingOptions arg4,edu.umn.msi.tropix.credential.types.CredentialResource arg5) throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).submitTrainingJob(arg1,arg2,arg3,arg4,arg5);
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public int getNumResults() throws RemoteException {
    return ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).getNumResults();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void getResults(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2) throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).getResults(arg1,arg2);
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public edu.umn.msi.tropix.common.jobqueue.status.Status getStatus() throws RemoteException {
    return ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).getStatus();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public edu.umn.msi.tropix.common.jobqueue.ticket.Ticket getTicket() throws RemoteException {
    return ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).getTicket();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void cancel() throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.ITraqQuantitationJobQueueContext)get__springBean__1()).cancel();
  }

}

