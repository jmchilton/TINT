package edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.service;

import edu.umn.msi.cagrid.introduce.interfaces.client.service.ImplementsForService;
import edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.service.ITraqQuantitationConfiguration;
import edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.service.ITraqQuantitationApplicationContext;
import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class ITraqQuantitationImpl extends ITraqQuantitationImplBase {
  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  java.lang.Object __springBean__2;

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  @ImplementsForService(interfaces = {"edu.umn.msi.tropix.common.jobqueue.service.StatusService"})
  private java.lang.Object get__springBean__2() {
    if(__springBean__2 == null) 
      __springBean__2 =  (java.lang.Object) ITraqQuantitationApplicationContext.get().getBean("statusService");
    return __springBean__2; 
  }
  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  private void __initSpring__(ITraqQuantitationConfiguration configuration) throws RemoteException 
  {
    ITraqQuantitationApplicationContext.init(configuration);
  }

	public ITraqQuantitationImpl() throws RemoteException {
		super();
		try { __initSpring__(getConfiguration()); } catch(Exception e) { throw new RemoteException("Failed to initialize beans.", e); }
	}
	
  public edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.jobcontext.stubs.types.ITraqQuantitationJobContextReference getJob(edu.umn.msi.tropix.common.jobqueue.ticket.Ticket ticket) throws RemoteException {
    return JobContextFactory.getJob(ticket);
  }

  public edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.jobcontext.stubs.types.ITraqQuantitationJobContextReference createJob() throws RemoteException {
    return JobContextFactory.createJob();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public edu.umn.msi.tropix.common.jobqueue.status.Status[] getStatuses(edu.umn.msi.tropix.common.jobqueue.ticket.Ticket[] arg1) throws RemoteException {
    return ((edu.umn.msi.tropix.common.jobqueue.service.StatusService)get__springBean__2()).getStatuses(arg1);
  }

}

