package edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.client;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

public class ITraqQuantitationInterfacesClient implements edu.umn.msi.tropix.common.jobqueue.service.StatusService  {
  private ITraqQuantitationClient caGridClient;

  public ITraqQuantitationInterfacesClient(String url) throws MalformedURIException, RemoteException {
    initialize(new ITraqQuantitationClient(url));
  }
  
  public ITraqQuantitationInterfacesClient(String url, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new ITraqQuantitationClient(url, proxy));
  }

  public ITraqQuantitationInterfacesClient(EndpointReferenceType epr) throws MalformedURIException, RemoteException {
    initialize(new ITraqQuantitationClient(epr));
  }

  public ITraqQuantitationInterfacesClient(EndpointReferenceType epr, GlobusCredential proxy) throws MalformedURIException, RemoteException {
    initialize(new ITraqQuantitationClient(epr, proxy));
  }
  
  public ITraqQuantitationInterfacesClient(ITraqQuantitationClient caGridClient) {
    initialize(caGridClient);
  }
        
  private void initialize(ITraqQuantitationClient caGridClient) {
    this.caGridClient = caGridClient;
  }		        

  public ITraqQuantitationClient getCaGridClient() {
  	return caGridClient;
  }
       
  public edu.umn.msi.tropix.common.jobqueue.status.Status[] getStatuses(edu.umn.msi.tropix.common.jobqueue.ticket.Ticket[] arg1) 
  {
    try 
    {
      return caGridClient.getStatuses(arg1);
    }
    catch(RemoteException e)
    {
      throw new RemoteRuntimeException(e);
    }
  }
  
  /**
   * The caGrid client methods throw RemoteExceptions. But most
   * methods of most interfaces do not declare RemoteExceptions.
   * For that reason when building a client class that implements
   * methods that do not allow RemoteExceptions, they are caught
   * and wrapped in this RuntimeException which does not need to 
   * be declared, allowing the client class to implement the 
   * specified interface.
   *
   */
  public class RemoteRuntimeException extends RuntimeException {
   
    public RemoteRuntimeException(RemoteException exception) {
      super(exception);
    }
    
    /**
     * @return The wrapped RemoteException.
     */
    public RemoteException getRemoteException() {
      Throwable cause = getCause();
      if(cause instanceof RemoteException) {
        return (RemoteException) cause;
      } else {
        throw new IllegalStateException("getCause() did not return a RemoteException");
      }
    }
  }
}
