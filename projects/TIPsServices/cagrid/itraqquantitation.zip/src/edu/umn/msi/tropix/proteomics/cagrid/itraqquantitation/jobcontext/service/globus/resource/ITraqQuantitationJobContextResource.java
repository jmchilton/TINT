package edu.umn.msi.tropix.proteomics.cagrid.itraqquantitation.jobcontext.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this ITraqQuantitationJobContextResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class ITraqQuantitationJobContextResource extends ITraqQuantitationJobContextResourceBase {

}
