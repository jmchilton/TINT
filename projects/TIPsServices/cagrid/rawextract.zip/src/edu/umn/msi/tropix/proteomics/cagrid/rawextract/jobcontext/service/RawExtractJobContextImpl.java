package edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service;

import edu.umn.msi.cagrid.introduce.interfaces.client.service.ImplementsForService;
import edu.umn.msi.tropix.proteomics.cagrid.rawextract.service.RawExtractConfiguration;
import edu.umn.msi.tropix.proteomics.cagrid.rawextract.service.RawExtractApplicationContext;
import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class RawExtractJobContextImpl extends RawExtractJobContextImplBase {
  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  java.lang.Object __springBean__1;

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @SpringIntroduceExtension
   */
  @ImplementsForService(interfaces = {"edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext"})
  private java.lang.Object get__springBean__1() {
    if(__springBean__1 == null) 
      __springBean__1 =  (java.lang.Object) RawExtractApplicationContext.get().getBean("rawExtractService");
    return __springBean__1; 
  }

	public RawExtractJobContextImpl() throws RemoteException {
		super();
	}
	
  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void submitJob(edu.umn.msi.tropix.transfer.types.TransferResource arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2,java.lang.String arg3,java.lang.String arg4) throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext)get__springBean__1()).submitJob(arg1,arg2,arg3,arg4);
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public int getNumResults() throws RemoteException {
    return ((edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext)get__springBean__1()).getNumResults();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void getResults(edu.umn.msi.tropix.transfer.types.TransferResource[] arg1,edu.umn.msi.tropix.credential.types.CredentialResource arg2) throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext)get__springBean__1()).getResults(arg1,arg2);
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public edu.umn.msi.tropix.common.jobqueue.status.Status getStatus() throws RemoteException {
    return ((edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext)get__springBean__1()).getStatus();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public edu.umn.msi.tropix.common.jobqueue.ticket.Ticket getTicket() throws RemoteException {
    return ((edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext)get__springBean__1()).getTicket();
  }

  /**
   * DO NOT REMOVE THIS COMMENT!
   * @InterfacesIntroduceExtension
   */
  public void cancel() throws RemoteException {
    ((edu.umn.msi.tropix.proteomics.service.RawExtractJobQueueContext)get__springBean__1()).cancel();
  }

}

