package edu.umn.msi.tropix.proteomics.cagrid.rawextract.service;

import java.rmi.RemoteException;

class JobContextFactory {

  public static edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.stubs.types.RawExtractJobContextReference createJob() throws RemoteException {
    org.apache.axis.message.addressing.EndpointReferenceType epr = new org.apache.axis.message.addressing.EndpointReferenceType();
    edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResourceHome home = null;
    org.globus.wsrf.ResourceKey resourceKey = null;
    org.apache.axis.MessageContext ctx = org.apache.axis.MessageContext.getCurrentContext();
    String servicePath = ctx.getTargetService();
    String homeName = org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME + servicePath + "/" + "rawExtractJobContextHome";

    try {
      javax.naming.Context initialContext = new javax.naming.InitialContext();
      home = (edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResourceHome) initialContext.lookup(homeName);
      resourceKey = home.createResource();

      //  Grab the newly created resource
      edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResource thisResource = (edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResource)home.find(resourceKey);

      //  This is where the creator of this resource type can set whatever needs
      //  to be set on the resource so that it can function appropriatly  for instance
      //  if you want the resouce to only have the query string then there is where you would
      //  give it the query string.

      // sample of setting creator only security.  This will only allow the caller that created
      // this resource to be able to use it.
      //thisResource.setSecurityDescriptor(gov.nih.nci.cagrid.introduce.servicetools.security.SecurityUtils.createCreatorOnlyResourceSecurityDescriptor());

      String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
      transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
      transportURL += "RawExtractJobContext";
      epr = org.globus.wsrf.utils.AddressingUtils.createEndpointReference(transportURL,resourceKey);
    } catch (Exception e) {
      throw new RemoteException("Error looking up RawExtractJobContext home:" + e.getMessage(), e);
    }

    //return the typed EPR
    edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.stubs.types.RawExtractJobContextReference ref = new edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.stubs.types.RawExtractJobContextReference();
    ref.setEndpointReference(epr);

    return ref;
  }

  public static edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.stubs.types.RawExtractJobContextReference getJob(edu.umn.msi.tropix.common.jobqueue.ticket.Ticket ticket) throws RemoteException {
    org.apache.axis.message.addressing.EndpointReferenceType epr = new org.apache.axis.message.addressing.EndpointReferenceType();
    edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResourceHome home = null;
    org.globus.wsrf.ResourceKey resourceKey = null;
    org.apache.axis.MessageContext ctx = org.apache.axis.MessageContext.getCurrentContext();
    String servicePath = ctx.getTargetService();
    String homeName = org.globus.wsrf.Constants.JNDI_SERVICES_BASE_NAME + servicePath + "/" + "rawExtractJobContextHome";

    try {
      javax.naming.Context initialContext = new javax.naming.InitialContext();
      home = (edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResourceHome) initialContext.lookup(homeName);
      resourceKey = home.createResource();

      //  Grab the newly created resource
      edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResource thisResource = (edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.service.globus.resource.RawExtractJobContextResource)home.find(resourceKey);

      //  This is where the creator of this resource type can set whatever needs
      //  to be set on the resource so that it can function appropriatly  for instance
      //  if you want the resouce to only have the query string then there is where you would
      //  give it the query string.

      // sample of setting creator only security.  This will only allow the caller that created
      // this resource to be able to use it.
      //thisResource.setSecurityDescriptor(gov.nih.nci.cagrid.introduce.servicetools.security.SecurityUtils.createCreatorOnlyResourceSecurityDescriptor());
      thisResource.setTicket(ticket);
      
      String transportURL = (String) ctx.getProperty(org.apache.axis.MessageContext.TRANS_URL);
      transportURL = transportURL.substring(0,transportURL.lastIndexOf('/') +1 );
      transportURL += "RawExtractJobContext";
      epr = org.globus.wsrf.utils.AddressingUtils.createEndpointReference(transportURL,resourceKey);
    } catch (Exception e) {
      throw new RemoteException("Error looking up RawExtractJobContext home:" + e.getMessage(), e);
    }

    //return the typed EPR
    edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.stubs.types.RawExtractJobContextReference ref = new edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.stubs.types.RawExtractJobContextReference();
    ref.setEndpointReference(epr);

    return ref;
  }
 

}
