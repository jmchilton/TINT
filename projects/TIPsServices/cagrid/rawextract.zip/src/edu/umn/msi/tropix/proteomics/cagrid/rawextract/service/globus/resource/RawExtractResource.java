package edu.umn.msi.tropix.proteomics.cagrid.rawextract.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this RawExtractResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class RawExtractResource extends RawExtractResourceBase {

}
