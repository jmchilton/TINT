package edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.common;

import javax.xml.namespace.QName;


public interface RawExtractJobContextConstants {
	public static final String SERVICE_NS = "http://msi.umn.edu/tropix/proteomics/RawExtract/JobContext";
	public static final QName RESOURCE_KEY = new QName(SERVICE_NS, "RawExtractJobContextKey");
	public static final QName RESOURCE_PROPERTY_SET = new QName(SERVICE_NS, "RawExtractJobContextResourceProperties");

	//Service level metadata (exposed as resouce properties)
	public static final QName CURRENTTIME = new QName("http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceLifetime-1.2-draft-01.xsd", "CurrentTime");
	public static final QName TERMINATIONTIME = new QName("http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceLifetime-1.2-draft-01.xsd", "TerminationTime");
	public static final QName TICKET = new QName("http://msi.umn.edu/tropix/common/jobqueue/ticket", "Ticket");
	
}
