package edu.umn.msi.tropix.proteomics.cagrid.rawextract.client;

import java.rmi.RemoteException;
import javax.annotation.Nullable;

import edu.umn.msi.tropix.common.jobqueue.client.JobClientFactory;
import edu.umn.msi.tropix.common.jobqueue.client.JobClientFactoryComponent;
import edu.umn.msi.tropix.common.jobqueue.ticket.Ticket;
import edu.umn.msi.tropix.grid.credentials.Credential;

import org.springframework.stereotype.Component;

import org.apache.axis.types.URI.MalformedURIException;

import org.globus.gsi.GlobusCredential;

import edu.umn.msi.tropix.proteomics.cagrid.rawextract.client.*;
import edu.umn.msi.tropix.proteomics.cagrid.rawextract.jobcontext.client.*;

@Component("edu.umn.msi.tropix.proteomics.cagrid.rawextract.JobClientFactory") @JobClientFactoryComponent(serviceName = "RawExtract", servicePackage = "edu.umn.msi.tropix.proteomics.cagrid.rawextract")
public class JobClientFactoryImpl implements JobClientFactory {

  public <T> T createJobContext(@Nullable Credential credential, String serviceUrl, Class<T> interfaceClass) {
    try {
      RawExtractClient client = new RawExtractClient(serviceUrl, getGlobusCredential(credential));
      RawExtractJobContextClient jobClient = client.createJob();
      return (T) new RawExtractJobContextInterfacesClient(jobClient);
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }
  
  public <T> T getJobClient(@Nullable Credential credential, String serviceUrl, Ticket ticket, Class<T> interfaceClass) {
    try {
      RawExtractClient client = new RawExtractClient(serviceUrl, getGlobusCredential(credential));
      RawExtractJobContextClient jobClient = client.getJob(ticket);
      return (T) new RawExtractJobContextInterfacesClient(jobClient);        
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }
  
  public <T> T getServiceClient(@Nullable Credential credential, String serviceUrl, Class<T> interfaceClass) {
    try {
      RawExtractInterfacesClient iClient = new RawExtractInterfacesClient(serviceUrl, getGlobusCredential(credential));
      return (T) iClient;  
    } catch(MalformedURIException e) {
      throw new RuntimeException(e);
    } catch(RemoteException e) {
      throw new RuntimeException(e);
    }       
  }

  @Nullable
  private GlobusCredential getGlobusCredential(@Nullable Credential credential) {
    return credential == null ? null : credential.getGlobusCredential();
  }
  

}
